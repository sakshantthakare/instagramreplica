import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

class ShimmerLoading extends StatelessWidget {
  const ShimmerLoading({super.key});

  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: Colors.grey[300]!,
      highlightColor: Colors.grey[100]!,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header shimmer
          ListTile(
            leading: const CircleAvatar(backgroundColor: Colors.white),
            title: Container(
              height: 10,
              width: 100,
              color: Colors.white,
            ),
          ),
          // Image shimmer
          Container(
            height: 400,
            width: double.infinity,
            color: Colors.white,
          ),
          // Actions shimmer
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Container(height: 24, width: 24, color: Colors.white),
                const SizedBox(width: 8),
                Container(height: 24, width: 24, color: Colors.white),
                const SizedBox(width: 8),
                Container(height: 24, width: 24, color: Colors.white),
              ],
            ),
          ),
          // Caption shimmer
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(height: 10, width: 150, color: Colors.white),
                const SizedBox(height: 8),
                Container(height: 10, width: double.infinity, color: Colors.white),
              ],
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}
