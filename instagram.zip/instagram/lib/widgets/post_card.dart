import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import '../models/post.dart';
import '../providers/home_provider.dart';

/// A custom widget representing an individual post card in the Instagram feed.
/// This widget handles complex interactions like pinch-to-zoom, carousel scrolling,
/// and local state updates for likes/bookmarks.
class PostCard extends StatefulWidget {
  final Post post;

  const PostCard({super.key, required this.post});

  @override
  State<PostCard> createState() => _PostCardState();
}

class _PostCardState extends State<PostCard> {
  // PageController manages the horizontal carousel for multi-image posts.
  final PageController _pageController = PageController();
  
  // TransformationController is essential for the Pinch-to-Zoom functionality.
  // It allows us to reset the zoom level programmatically when the interaction ends.
  final TransformationController _transformationController = TransformationController();

  /// Displays a persistent snackbar for features that are not yet implemented.
  void _triggerFeaturePlaceholder(BuildContext context, String featureName) {
    ScaffoldMessenger.of(context).removeCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('$featureName is not implemented in this demo.'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // --- POST HEADER ---
        // Displays the user profile, handle, and metadata.
        _buildPostHeader(),

        // --- MEDIA CAROUSEL & INTERACTION LAYER ---
        // Includes the image, zoom functionality, and floating overlays.
        _buildPostMedia(),

        // --- INTERACTION BUTTONS ---
        // Heart, Comment, Share, and Bookmark icons.
        _buildActionRow(context),

        // --- CAPTION & ENGAGEMENT SECTION ---
        // Likes count, caption text, and timestamp.
        _buildEngagementDetails(),
      ],
    );
  }

  Widget _buildPostHeader() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8.0),
      child: Row(
        children: [
          CircleAvatar(
            radius: 16,
            backgroundColor: Colors.grey[200],
            backgroundImage: CachedNetworkImageProvider(widget.post.userProfileUrl),
          ),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                widget.post.username,
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
              ),
              const Text(
                'Original Audio • Photography',
                style: TextStyle(fontSize: 11, color: Colors.grey),
              ),
            ],
          ),
          const Spacer(),
          const Icon(Icons.more_vert, size: 20),
        ],
      ),
    );
  }

  Widget _buildPostMedia() {
    return AspectRatio(
      aspectRatio: 1.0,
      child: Stack(
        children: [
          PageView.builder(
            controller: _pageController,
            itemCount: widget.post.imageUrls.length,
            onPageChanged: (index) => setState(() {}), // Update the counter overlay
            itemBuilder: (context, index) {
              // Pinch-to-Zoom implementation using InteractiveViewer.
              return InteractiveViewer(
                transformationController: _transformationController,
                clipBehavior: Clip.none, // Allow the image to scale over the UI
                onInteractionEnd: (details) {
                  // Requirement: Animate back to original position on release.
                  _transformationController.value = Matrix4.identity();
                },
                child: CachedNetworkImage(
                  imageUrl: widget.post.imageUrls[index],
                  fit: BoxFit.cover,
                  placeholder: (context, url) => Container(color: Colors.grey[100]),
                  errorWidget: (context, url, error) => Container(
                    color: Colors.grey[200],
                    child: const Icon(Icons.broken_image_outlined, color: Colors.grey),
                  ),
                ),
              );
            },
          ),
          
          // Page Indicator Overlay (e.g., "1/3")
          if (widget.post.imageUrls.length > 1)
            Positioned(
              top: 12,
              right: 12,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.7),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  '${(_pageController.hasClients ? _pageController.page?.round() ?? 0 : 0) + 1}/${widget.post.imageUrls.length}',
                  style: const TextStyle(color: Colors.white, fontSize: 11),
                ),
              ),
            ),

          // User tag and mute icons (Replicating latest UI details)
          _buildFloatingMediaOverlays(),
        ],
      ),
    );
  }

  Widget _buildFloatingMediaOverlays() {
    return Stack(
      children: [
        Positioned(
          bottom: 12,
          left: 12,
          child: Row(
            children: [
              CircleAvatar(
                radius: 12,
                backgroundColor: Colors.white30,
                backgroundImage: CachedNetworkImageProvider(widget.post.userProfileUrl),
              ),
              const SizedBox(width: 8),
              const Icon(Icons.person_pin_circle_outlined, color: Colors.white, size: 24),
            ],
          ),
        ),
        Positioned(
          bottom: 12,
          right: 12,
          child: Container(
            padding: const EdgeInsets.all(4),
            decoration: const BoxDecoration(color: Colors.black45, shape: BoxShape.circle),
            child: const Icon(Icons.volume_off, color: Colors.white, size: 14),
          ),
        ),
      ],
    );
  }

  Widget _buildActionRow(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4.0, vertical: 2.0),
      child: Row(
        children: [
          // Stateful Like Toggle
          IconButton(
            onPressed: () => context.read<HomeProvider>().toggleLike(widget.post.id),
            icon: Icon(
              widget.post.isLiked ? FontAwesomeIcons.solidHeart : FontAwesomeIcons.heart,
              color: widget.post.isLiked ? Colors.red : Colors.black,
              size: 24,
            ),
          ),
          const Text('1.2k', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
          
          IconButton(
            onPressed: () => _triggerFeaturePlaceholder(context, 'Comments'),
            icon: const Icon(FontAwesomeIcons.comment, size: 24),
          ),
          const Text('45', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),

          IconButton(
            onPressed: () => _triggerFeaturePlaceholder(context, 'Repost'),
            icon: const Icon(Icons.repeat, size: 26),
          ),
          const Text('12', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),

          IconButton(
            onPressed: () => _triggerFeaturePlaceholder(context, 'Share'),
            icon: const Icon(FontAwesomeIcons.paperPlane, size: 24),
          ),
          const Text('8', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),

          const Spacer(),
          
          // Carousel Dot Indicator
          if (widget.post.imageUrls.length > 1)
            SmoothPageIndicator(
              controller: _pageController,
              count: widget.post.imageUrls.length,
              effect: const ScrollingDotsEffect(
                activeDotColor: Colors.blue,
                dotColor: Colors.grey,
                dotHeight: 6,
                dotWidth: 6,
              ),
            ),

          const Spacer(),
          
          // Stateful Save/Bookmark Toggle
          IconButton(
            onPressed: () => context.read<HomeProvider>().toggleSave(widget.post.id),
            icon: Icon(
              widget.post.isSaved ? FontAwesomeIcons.solidBookmark : FontAwesomeIcons.bookmark,
              size: 24,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEngagementDetails() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          RichText(
            text: TextSpan(
              style: const TextStyle(color: Colors.black, fontSize: 13),
              children: [
                TextSpan(
                  text: '${widget.post.username} ',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                TextSpan(text: widget.post.caption),
                const TextSpan(text: '... more', style: TextStyle(color: Colors.grey)),
              ],
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            '4 hours ago • See translation',
            style: TextStyle(color: Colors.grey, fontSize: 11),
          ),
          const SizedBox(height: 12),
        ],
      ),
    );
  }
}
