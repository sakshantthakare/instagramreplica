import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/home_provider.dart';
import 'screens/home_screen.dart';

/// Entry point of the Instagram Replica Application.
/// This project demonstrates high-fidelity UI replication, complex touch interactions,
/// and clean architectural patterns as per the "Pixel-Perfect" challenge.
void main() {
  runApp(
    // MultiProvider setup for scalable state management.
    // Provider is chosen for its efficiency and clear separation of concerns.
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => HomeProvider()),
      ],
      child: const InstagramReplicaApp(),
    ),
  );
}

class InstagramReplicaApp extends StatelessWidget {
  const InstagramReplicaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Instagram Replica',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        // Adopting a clean, white background consistent with modern Instagram UI.
        scaffoldBackgroundColor: Colors.white,
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          elevation: 0,
          centerTitle: true,
          iconTheme: IconThemeData(color: Colors.black),
        ),
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.black),
        useMaterial3: true,
      ),
      // Starting with the Home Feed screen.
      home: const HomeScreen(),
    );
  }
}
