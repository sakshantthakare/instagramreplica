import 'package:flutter/material.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Notifications',
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        children: [
          const Padding(
            padding: EdgeInsets.all(16.0),
            child: Text('Today', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          ),
          _buildNotificationItem(
            'supreme_player_',
            'accepted your follow request.',
            '4h',
            showActionButton: true,
            actionLabel: 'Message',
          ),
          const Padding(
            padding: EdgeInsets.all(16.0),
            child: Text('Last 30 days', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          ),
          _buildNotificationItem(
            'supreme_player_',
            'started following you.',
            '3w',
            showActionButton: true,
            actionLabel: 'Message',
          ),
          _buildSuggestionItem('Follow suggestions: Priyanka, Pratik Bhosale and others', '4w'),
          const Padding(
            padding: EdgeInsets.all(16.0),
            child: Text('Older', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          ),
          _buildInfoItem('Another account is using your phone number. You can update your info.', '4w'),
          _buildNotificationItem(
            'dahakeman7',
            'started following you.',
            '6w',
            showActionButton: true,
            actionLabel: 'Message',
          ),
          _buildNotificationItem(
            'iblame_anokhi',
            'is on Instagram. manjiri_643 follows them.',
            '7w',
            showActionButton: true,
            actionLabel: 'Follow',
            isFollowAction: true,
          ),
        ],
      ),
    );
  }

  Widget _buildNotificationItem(String username, String text, String time,
      {bool showActionButton = false, String actionLabel = '', bool isFollowAction = false}) {
    return ListTile(
      leading: CircleAvatar(
        radius: 20,
        backgroundColor: Colors.grey[300],
        backgroundImage: const NetworkImage('https://picsum.photos/seed/notif/200'),
      ),
      title: RichText(
        text: TextSpan(
          style: const TextStyle(color: Colors.black, fontSize: 14),
          children: [
            TextSpan(text: '$username ', style: const TextStyle(fontWeight: FontWeight.bold)),
            TextSpan(text: text),
            TextSpan(text: ' $time', style: const TextStyle(color: Colors.grey)),
          ],
        ),
      ),
      trailing: showActionButton
          ? Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              decoration: BoxDecoration(
                color: isFollowAction ? Colors.blue : Colors.grey[200],
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                actionLabel,
                style: TextStyle(
                  color: isFollowAction ? Colors.white : Colors.black,
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                ),
              ),
            )
          : null,
    );
  }

  Widget _buildSuggestionItem(String text, String time) {
    return ListTile(
      leading: CircleAvatar(
        radius: 20,
        backgroundColor: Colors.grey[300],
        child: const Icon(Icons.people, color: Colors.white),
      ),
      title: RichText(
        text: TextSpan(
          style: const TextStyle(color: Colors.black, fontSize: 14),
          children: [
            TextSpan(text: text),
            TextSpan(text: ' $time', style: const TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoItem(String text, String time) {
    return ListTile(
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.grey)),
        child: const Icon(Icons.info_outline, size: 20),
      ),
      title: RichText(
        text: TextSpan(
          style: const TextStyle(color: Colors.black, fontSize: 14),
          children: [
            TextSpan(text: text),
            TextSpan(text: ' $time', style: const TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}
