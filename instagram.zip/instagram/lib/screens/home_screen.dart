import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';
import '../providers/home_provider.dart';
import '../widgets/post_card.dart';
import '../widgets/shimmer_loading.dart';
import '../widgets/story_tray.dart';
import 'notifications_screen.dart';
import 'new_post_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<HomeProvider>().init();
    });

    _scrollController.addListener(() {
      if (_scrollController.position.pixels >=
          _scrollController.position.maxScrollExtent - 500) {
        context.read<HomeProvider>().fetchPosts();
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _showUnimplementedSnackbar(String message) {
    ScaffoldMessenger.of(context).removeCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _showInstagramMenu() {
    showDialog(
      context: context,
      builder: (context) => Stack(
        children: [
          Positioned(
            top: 100,
            left: 20,
            child: Material(
              color: Colors.transparent,
              child: Container(
                width: 200,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(color: Colors.black26, blurRadius: 10, offset: Offset(0, 5)),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ListTile(
                      leading: const Icon(Icons.people_outline, color: Colors.black),
                      title: const Text('Following', style: TextStyle(fontWeight: FontWeight.w500)),
                      onTap: () => Navigator.pop(context),
                    ),
                    const Divider(height: 1),
                    ListTile(
                      leading: const Icon(Icons.star_border, color: Colors.black),
                      title: const Text('Favorites', style: TextStyle(fontWeight: FontWeight.w500)),
                      onTap: () => Navigator.pop(context),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.add_box_outlined, color: Colors.black, size: 28),
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const NewPostScreen()),
          ),
        ),
        title: InkWell(
          onTap: _showInstagramMenu,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: const [
              Text(
                'Instagram',
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  letterSpacing: -1.2,
                ),
              ),
              Icon(Icons.keyboard_arrow_down, color: Colors.black, size: 20),
            ],
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(FontAwesomeIcons.heart, color: Colors.black, size: 22),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const NotificationsScreen()),
            ),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () => context.read<HomeProvider>().fetchPosts(refresh: true),
        child: Consumer<HomeProvider>(
          builder: (context, provider, child) {
            return CustomScrollView(
              controller: _scrollController,
              slivers: [
                SliverToBoxAdapter(
                  child: StoryTray(
                    stories: provider.stories,
                    isLoading: provider.isLoadingStories,
                  ),
                ),
                SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (context, index) {
                      if (index < provider.posts.length) {
                        return PostCard(post: provider.posts[index]);
                      } else if (provider.isLoadingPosts) {
                        return const Padding(
                          padding: EdgeInsets.symmetric(vertical: 32.0),
                          child: ShimmerLoading(),
                        );
                      } else {
                        return const SizedBox(height: 50);
                      }
                    },
                    childCount: provider.posts.length + (provider.isLoadingPosts ? 1 : 0),
                  ),
                ),
              ],
            );
          },
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        showSelectedLabels: false,
        showUnselectedLabels: false,
        selectedItemColor: Colors.black,
        unselectedItemColor: Colors.black,
        items: [
          const BottomNavigationBarItem(icon: Icon(Icons.home_filled, size: 28), label: 'Home'),
          const BottomNavigationBarItem(icon: Icon(Icons.movie_outlined, size: 28), label: 'Reels'),
          const BottomNavigationBarItem(icon: Icon(Icons.add_box_outlined, size: 28), label: 'Add'),
          const BottomNavigationBarItem(icon: Icon(Icons.search, size: 28), label: 'Search'),
          BottomNavigationBarItem(
            icon: Container(
              padding: const EdgeInsets.all(1.5),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: Colors.black, width: 1.2),
              ),
              child: const CircleAvatar(
                radius: 11,
                backgroundImage: NetworkImage('https://picsum.photos/seed/profile/200'),
              ),
            ),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}
