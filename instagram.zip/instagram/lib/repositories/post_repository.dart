import 'dart:async';
import '../models/post.dart';

/// Repository responsible for data orchestration.
/// Implements a mock data layer with simulated latency to demonstrate 
/// robust loading state handling (shimmers).
class PostRepository {
  
  /// Mock database of posts. In a real-world scenario, this would be an API call.
  final List<Post> _allPosts = List.generate(
    50,
    (index) => Post(
      id: index.toString(),
      username: 'user_handle_$index',
      userProfileUrl: 'https://picsum.photos/seed/user$index/200',
      imageUrls: [
        'https://picsum.photos/seed/post${index}_1/1080',
        if (index % 2 == 0) 'https://picsum.photos/seed/post${index}_2/1080',
        if (index % 3 == 0) 'https://picsum.photos/seed/post${index}_3/1080',
      ],
      caption: 'Obsessive replication of the Instagram feed. #flutter #dart #pixelperfect #uiux',
      likesCount: (index + 1) * 42,
      postedAt: DateTime.now().subtract(Duration(hours: index * 2)),
    ),
  );

  /// Mock data for the horizontal Stories tray.
  final List<Story> _stories = List.generate(
    15,
    (index) => Story(
      username: index == 0 ? 'Your story' : 'friend_$index',
      profileUrl: 'https://picsum.photos/seed/story$index/200',
      isLive: index == 2, // Simulating a "Live" story state.
    ),
  );

  /// Fetches a paginated list of posts.
  /// Implements a mandatory 1.5s delay to showcase shimmer effects.
  Future<List<Post>> fetchPosts({int page = 0, int limit = 10}) async {
    // Latency Simulation: Required by the challenge.
    await Future.delayed(const Duration(milliseconds: 1500));
    
    int start = page * limit;
    int end = start + limit;
    
    if (start >= _allPosts.length) return [];
    if (end > _allPosts.length) end = _allPosts.length;
    
    return _allPosts.sublist(start, end);
  }

  /// Fetches stories for the top tray.
  Future<List<Story>> fetchStories() async {
    await Future.delayed(const Duration(milliseconds: 800));
    return _stories;
  }
}
