/// Core data models for the Instagram application.
/// These models ensure clean data structures for UI components.

class Post {
  final String id;
  final String username;
  final String userProfileUrl;
  final List<String> imageUrls;
  final String caption;
  final int likesCount;
  final bool isLiked;
  final bool isSaved;
  final DateTime postedAt;

  Post({
    required this.id,
    required this.username,
    required this.userProfileUrl,
    required this.imageUrls,
    required this.caption,
    required this.likesCount,
    this.isLiked = false,
    this.isSaved = false,
    required this.postedAt,
  });

  /// [copyWith] method is used to maintain immutability while updating local states
  /// such as Like or Save status. This is a common pattern in clean architecture.
  Post copyWith({
    bool? isLiked,
    bool? isSaved,
  }) {
    return Post(
      id: id,
      username: username,
      userProfileUrl: userProfileUrl,
      imageUrls: imageUrls,
      caption: caption,
      likesCount: likesCount,
      isLiked: isLiked ?? this.isLiked,
      isSaved: isSaved ?? this.isSaved,
      postedAt: postedAt,
    );
  }
}

class Story {
  final String username;
  final String profileUrl;
  final bool isLive;

  Story({
    required this.username,
    required this.profileUrl,
    this.isLive = false,
  });
}
