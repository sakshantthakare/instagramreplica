import 'package:flutter/material.dart';
import '../models/post.dart';
import '../repositories/post_repository.dart';

/// State Management Provider for the Home Feed.
/// This class handles data fetching, pagination, and local state toggles.
/// Separation of business logic from UI ensures a clean, testable codebase.
class HomeProvider extends ChangeNotifier {
  final PostRepository _repository = PostRepository();
  
  List<Post> _posts = [];
  List<Story> _stories = [];
  bool _isLoadingPosts = false;
  bool _isLoadingStories = false;
  int _currentPage = 0;
  bool _hasMore = true;

  List<Post> get posts => _posts;
  List<Story> get stories => _stories;
  bool get isLoadingPosts => _isLoadingPosts;
  bool get isLoadingStories => _isLoadingStories;

  /// Initializes the provider by fetching stories and the first page of posts.
  Future<void> init() async {
    fetchStories();
    fetchPosts();
  }

  /// Fetches stories for the horizontal stories tray.
  Future<void> fetchStories() async {
    _isLoadingStories = true;
    notifyListeners();
    _stories = await _repository.fetchStories();
    _isLoadingStories = false;
    notifyListeners();
  }

  /// Fetches paginated posts from the repository.
  /// [refresh] resets the state to the first page.
  Future<void> fetchPosts({bool refresh = false}) async {
    if (refresh) {
      _currentPage = 0;
      _posts = [];
      _hasMore = true;
    }

    if (!_hasMore || _isLoadingPosts) return;

    _isLoadingPosts = true;
    notifyListeners();

    final newPosts = await _repository.fetchPosts(page: _currentPage);
    
    if (newPosts.isEmpty) {
      _hasMore = false;
    } else {
      _posts.addAll(newPosts);
      _currentPage++;
    }

    _isLoadingPosts = false;
    notifyListeners();
  }

  /// Locally toggles the "Like" state for a specific post.
  /// This provides immediate UI feedback without a network call.
  void toggleLike(String postId) {
    final index = _posts.indexWhere((p) => p.id == postId);
    if (index != -1) {
      _posts[index] = _posts[index].copyWith(isLiked: !_posts[index].isLiked);
      notifyListeners();
    }
  }

  /// Locally toggles the "Save" state for a specific post.
  void toggleSave(String postId) {
    final index = _posts.indexWhere((p) => p.id == postId);
    if (index != -1) {
      _posts[index] = _posts[index].copyWith(isSaved: !_posts[index].isSaved);
      notifyListeners();
    }
  }
}
